#!/usr/bin/env python
# coding: utf-8

# # importing libraries

# In[329]:


import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')
from sklearn import preprocessing
import pickle


# In[330]:


os.chdir("C:/Users/P NIVAS/Desktop/Remote Internship-2020/Datasets")


# # importing dataset 

# In[331]:



data1=pd.read_csv("cereal.csv")
data1


# In[332]:


data1.describe()


# In[333]:


data1.cov()


# In[334]:


data1.corr()


# In[335]:


data1.head()


# In[336]:



data1.tail()


# In[337]:


data1.columns


# In[338]:


data1.dtypes


# In[339]:


data1['mfr'].unique()


# In[340]:


data1['type'].unique()


# In[341]:


data1['calories'].unique()


# In[342]:


data1['protein'].unique()


# In[343]:


data1['fat'].unique()


# In[344]:


data1['sodium'].unique()


# In[345]:


data1['sugars'].unique()


# In[346]:


data1['fiber'].unique()


# In[347]:


data1['vitamins'].unique()


# In[348]:


data1['cups'].unique()


# In[349]:


data1['weight'].unique()


# In[350]:


data1['shelf'].unique()


# In[351]:


data1['potass'].unique()


# In[352]:


data1.isnull()


# In[353]:


data1.any()


# #  data visualization

# In[354]:


data1['sodium'].hist(bins=10)


# In[355]:


#most of the cereals have sodium content between  130 to 220


# In[356]:


data1['rating'].hist(bins=10)


# In[357]:


#rating is maximum in between 25 to 42


# In[358]:


data1['type'].hist(bins=10)


# In[359]:


#mostly the type is 'C'


# In[360]:


data1['calories'].hist(bins=10)


# In[361]:


#calories are between 90 and 120


# In[362]:


data1['protein'].hist(bins=10)


# In[363]:


#protein value is mostly 2 and 3


# In[364]:


data1['fat'].hist(bins=10)


# In[365]:


#fat is mostly 0 or 1


# In[366]:


data1['fiber'].hist(bins=10)


# In[367]:


#fiber content is in between 0 to 4


# In[368]:


data1['carbo'].hist(bins=10)


# In[369]:


#carbohydrates are in between 12 to 18


# In[370]:


data1['sugars'].hist(bins=10)


# In[371]:


#sugars have most at 3 and 13 


# In[372]:


data1['potass'].hist(bins=10)


# In[373]:


#potassium is higher at 40 to 60


# In[374]:


data1.boxplot(column='rating',by='sodium')


# In[375]:


data1.boxplot(column='rating',by='cups')


# In[376]:


data1.boxplot(column='rating',by='calories')


# In[377]:


data1.boxplot(column='rating',by='protein')


# In[378]:


data1.boxplot(column='rating',by='fat')


# In[379]:


data1.boxplot(column='rating',by='fiber')


# In[380]:


data1.boxplot(column='rating',by='carbo')


# In[381]:


data1.boxplot(column='rating',by='sugars')


# In[382]:


data1.boxplot(column='rating',by='potass')


# In[383]:


data1.boxplot(column='rating',by='vitamins')


# In[384]:


data1.boxplot(column='rating',by='shelf')


# In[385]:


data1.boxplot(column='rating',by='weight')


# In[386]:


#Through boxplot we can conclude that there are no outliers


# # Taking Care Of Missing Data

# In[387]:


data=pd.read_csv("cereal.csv")


# In[388]:


data


# In[389]:


data.isnull()


# In[390]:


data.apply(lambda x: sum(x.isnull()),axis=0)


# In[391]:


#from the above output, we can concluded that there are no null values, so we can cnclude that there are no missing values


# In[392]:


data['type'].unique()


# In[393]:


#since 'type' has only two unique values lable encoding can be applied to it


# # Label Encoding

# In[394]:


from sklearn.preprocessing import LabelEncoder
lb=LabelEncoder()
lb2=LabelEncoder()
data['type']=lb.fit_transform(data['type'])
data


# # One Hot Encoding

# In[395]:


#since 'mfr' does not effect rating of cereals there is no need to encode it
#Also there are no other columns to encode, So there is no need of "One Hot Encoding"


# # Feature Scaling

# In[396]:


x=data.iloc[:,2:15]
x


# In[397]:


y=data.iloc[:,15].values
y


# In[398]:


minmax=preprocessing.MinMaxScaler(feature_range=(0,1))
minmax.fit(x).transform(x)


# # splitting the Dataset into Training and Test Set

# In[399]:


from sklearn import model_selection, neighbors
from sklearn.model_selection import train_test_split,cross_val_score,cross_val_predict
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.3)


# In[400]:


y_train


# In[401]:


x_train


# In[402]:


y_test


# In[403]:


x_train


# # Training and Testing the Model

# # # 1.Multiple linear Regression 

# In[404]:


import statsmodels.api as sm


# In[405]:


x=data[["protein","carbo","sugars","weight","calories","fat","sodium","fiber","potass"]]


# In[406]:


y=data["rating"]


# In[407]:


model1 = sm.OLS(y,x).fit()
predictions = model1.predict(x)
model1.summary()


# In[408]:


from sklearn import model_selection, neighbors
from sklearn.model_selection import train_test_split,cross_val_score,cross_val_predict
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.3,random_state=1)


# In[409]:


x_train


# In[410]:


y_train


# In[411]:


x_test


# In[412]:


y_test


# In[413]:


# define the data/predictors as the pre-set feature names  
features = x_train.iloc[:,:].values


# In[414]:


features


# In[415]:


labels = y_train.iloc[:].values


# In[416]:


labels


# In[417]:


x=features
y=labels


# In[418]:


# Instantiate Multiple linear regrssion model
from sklearn import linear_model as lm
model=lm.LinearRegression()
results=model.fit(x,y) 


# In[419]:


predictions = model.predict(x)


# In[420]:


pickle.dump(model,open('cereal.pkl','wb'))


# In[421]:


load1=pickle.load(open('cereal.pkl','rb'))


# In[422]:


print(load1.predict([[4,5,6,1,70,1,130,10,280]]))


# In[423]:


#Check model accuracy
accuracy=model.score(x,y)
print('Accuracy of the model:', accuracy)


# In[424]:


#Visualize the predictions
plt.scatter(y, predictions)


# In[425]:


#Evaluating the model 
from sklearn.metrics import mean_squared_error, r2_score

# printing values
print('Slope:' ,model.coef_)
print('Intercept:', model.intercept_)
print("\n")


import numpy as np
rmse = (np.sqrt(mean_squared_error(y,predictions)))
r2 = r2_score(y,predictions)

print("The model performance")
print("--------------------------------------")
print('RMSE is {}'.format(rmse))
print('R2 score is {}'.format(r2))
print("\n")


# # # 2.Decision Tree Regression

# In[426]:


x=data[["protein","carbo","sugars","weight","calories","fat","sodium","fiber","potass"]].values
y=data.iloc[:,15].values


# In[427]:


x


# In[428]:


y


# In[429]:


#Fit Decision Tree Rgerssion Model to the dataset
from sklearn.tree import DecisionTreeRegressor
#Create the Decision Tree regressor object 
regressor = DecisionTreeRegressor(random_state=0)


# In[430]:


#Fit the regressor object to the dataset.
regressor.fit(x,y)


# In[431]:


#Predict a new result
y_pred = regressor.predict([[6,6,9,1,72,1.2,13,10.2,81]])


# In[432]:


y_pred


# In[ ]:




