#!/usr/bin/env python
# coding: utf-8

# In[6]:


import os
import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')
from sklearn import preprocessing
import pickle


# In[7]:


os.chdir(r"C:\Users\pavan\Downloads\Internship2020\Project\Deployment-flask")

data=pd.read_csv("cereal.csv")
data


# In[9]:


data.apply(lambda x: sum(x.isnull()),axis=0)


# In[10]:


from sklearn.preprocessing import LabelEncoder
lb=LabelEncoder()
lb2=LabelEncoder()
data['type']=lb.fit_transform(data['type'])
data


# In[12]:


x=data.iloc[:,2:15]


# In[13]:


y=data.iloc[:,15].values


# In[14]:


minmax=preprocessing.MinMaxScaler(feature_range=(0,1))
minmax.fit(x).transform(x)


# In[15]:


from sklearn import model_selection, neighbors
from sklearn.model_selection import train_test_split,cross_val_score,cross_val_predict
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.3)


# In[16]:


import statsmodels.api as sm


# In[17]:


x=data[["protein","carbo","sugars","weight","calories","fat","sodium","fiber","potass"]]
y=data["rating"]


# In[18]:


model1 = sm.OLS(y,x).fit()
predictions = model1.predict(x)
model1.summary()


# In[19]:


from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.3,random_state=1)


# In[20]:


# define the data/predictors as the pre-set feature names  
features = x_train.iloc[:,:].values
labels = y_train.iloc[:].values
x=features
y=labels


# In[21]:


# Instantiate Multiple linear regrssion model
from sklearn import linear_model as lm
regressor=lm.LinearRegression()
regressor.fit(x,y) 


# In[22]:

pickle.dump(regressor,open('cereal.pkl','wb'))
model=pickle.load(open('cereal.pkl','rb'))
print(model.predict([[4,5,6,1,70,1,130,10,280]]))


# In[ ]:




