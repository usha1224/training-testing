import requests

url = 'http://localhost:5000/predict_api'
r = requests.post(url,json={'protein':4, 'carbo':5, 'sugars':6,'weight':1,'calories':70,'fat':1,
                            'sodium':130,'fiber':10,'pootass':280})

print(r.json())
